from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_pymongo import PyMongo
from flask_bcrypt import Bcrypt
from bson import ObjectId

# Initialize Flask app, MongoDB, and Bcrypt
app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/forum'
app.secret_key = 'your_secret_key'  # Secret key for session management
mongo = PyMongo(app)
bcrypt = Bcrypt(app)

# Access the 'users' and 'posts' collections from MongoDB
users_collection = mongo.db.users
posts_collection = mongo.db.posts


@app.route('/')
def home():
    return render_template('home.html')  # Welcome page with links to login and register


# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if username already exists
        if users_collection.find_one({'username': username}):
            flash('Username already taken. Please choose another.', 'danger')
            return render_template('register.html')

        # Hash password before saving it
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        # Insert new user into the database
        users_collection.insert_one({'username': username, 'password': hashed_password, 'likes': []})

        flash('Registration successful! Please login.', 'success')

        # Redirect to login page after successful registration
        return redirect(url_for('login'))

    return render_template('register.html')


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Find user from MongoDB by username
        user = users_collection.find_one({'username': username})

        if user and bcrypt.check_password_hash(user['password'], password):
            # Store user session if login is successful
            session['user_id'] = str(user['_id'])
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))  # Redirect to the dashboard after login
        else:
            flash('Invalid credentials. Please try again.', 'danger')

    return render_template('login.html')


# Dashboard route (accessible after login)
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    # Fetch posts from the database
    posts = posts_collection.find()

    # Fetch the logged-in user's details
    user = users_collection.find_one({'_id':ObjectId(session['user_id'])})

    return render_template('dashboard.html', posts=posts, user=user)


# Like a post
@app.route('/like/<post_id>', methods=['POST'])
def like(post_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    # Fetch the post and the logged-in user
    post = posts_collection.find_one({'_id': ObjectId(post_id)})
    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})

    # Check if the user has already liked the post
    if post['_id'] in user['likes']:
        flash('You have already liked this post!', 'warning')
    else:
        # Add the post ID to the user's likes
        users_collection.update_one(
            {'_id': ObjectId(session['user_id'])},
            {'$push': {'likes': post['_id']}}
        )
        # Increment the like count for the post
        posts_collection.update_one(
            {'_id': ObjectId(post_id)},
            {'$inc': {'like_count': 1}}
        )
        flash('Post liked successfully!', 'success')

    return redirect(url_for('dashboard'))

# Update user profile
@app.route('/update_profile', methods=['GET', 'POST'])
def update_profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Hash new password
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        # Update user details in the database
        users_collection.update_one(
            {'_id': ObjectId(session['user_id'])},
            {'$set': {'username': username, 'password': hashed_password}}
        )

        flash('Profile updated successfully!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('update_profile.html', user=user)


# Logout route
@app.route('/logout')
def logout():
    session.pop('user_id', None)  # Remove user session
    flash('Logged out successfully!', 'success')
    return redirect(url_for('home'))  # Redirect to home page


if __name__ == '__main__':
    app.run(debug=True)
